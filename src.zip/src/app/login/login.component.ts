import { Component, OnInit } from '@angular/core';
import { AuthService } from '../services/auth.service';
import { Router } from '@angular/router';



@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  /*credentials={
    emailId:'',
    password:''
  }
  successMessage: string | null = null;
  errorMessage: string | null = null;
  
  constructor(private authService:AuthService, private router: Router){//adding todo list page

  }
  ngOnInit():void{

  }
  onSubmit() {
    if (this.credentials.emailId && this.credentials.password) {
      this.authService.generateToken(this.credentials).subscribe(
        (response: any) => { 
          console.log('Login success:', response);
          const token = response.token; 
          if (token) {
            this.successMessage = 'Login successful!';
            this.authService.setAuthenticated(true, token); // Pass the token to setAuthenticated
            this.router.navigate(['/todo-list']);
          } else {
            console.error('Token not found in the response.');
            this.errorMessage = 'Login failed.';
          }
        },
        error => {
          console.log(error);
          this.errorMessage = 'Login failed.';
        }
      );
    } else {
      console.log('Fields are empty');
    }
  }*/
  credentials = {
    emailId: '',
    password: ''
  };
  successMessage: string | null = null;
  errorMessage: string | null = null;
  task1: any[] = [];

  constructor(private authService: AuthService, private router: Router) {}

  ngOnInit(): void {}

  /* onSubmit() {
    if (this.credentials.emailId && this.credentials.password) {
      this.authService.generateToken(this.credentials).subscribe(
        (response: any) => {
          console.log('Login success:', response);
          const token = response.token;
          if (token) {
            this.successMessage = 'Login successful!';
            this.authService.setAuthenticated(true, token);// Pass the token to setAuthenticated
            this.router.navigate(['/todo-list']);
          } else {
            console.error('Token not found in the response.');
            this.errorMessage = 'Login failed.';
          }
        },
        error => {
          console.log(error);
          this.errorMessage = 'Login failed.';
        }
      );
    } else {
      console.log('Fields are empty');
    }
  }*/



  onSubmit() {
    if (!this.credentials.emailId || !this.credentials.password) {
      this.errorMessage = 'Fields are empty. Please enter your email address and password.';
      return; // Exit the function early if fields are empty
    }
  
    this.authService.generateToken(this.credentials).subscribe(
      (response: any) => {
        console.log('Login success:', response);
        const token = response.token;
        if (token) {
          this.successMessage = 'Login successful!';
          this.authService.setAuthenticated(true, token);// Pass the token to setAuthenticated
          this.router.navigate(['/todo-list']);
        } else {
          console.error('Token not found in the response.');
          this.errorMessage = 'Login failed.';
        }
      },
      error => {
        console.log('Login error:', error);
        if (error.error && typeof error.error === 'string') {
          // If the error is a string, assume it's a custom error message from the server
          this.errorMessage = 'Login failed. ' + error.error;
        } else {
          this.errorMessage = 'Login failed Please check your email address and password.';
        }
      }
    );
  }  
  

  reset() {
    this.errorMessage = null;
    this.credentials = {
      emailId: '',
      password: ''
    };
  }
  

}