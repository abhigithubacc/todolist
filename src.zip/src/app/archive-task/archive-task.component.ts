import { Component, Input, OnInit } from '@angular/core';
import { AuthService } from '../services/auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-archive-task',
  templateUrl: './archive-task.component.html',
  styleUrls: ['./archive-task.component.css']
})
export class ArchiveTaskComponent  implements OnInit {
  @Input() task: any; // Define task as an input property
   archivedTaskList: any[] = [];
  constructor(private authService: AuthService, private router: Router) { }

  ngOnInit(): void {
    this.getArchivedTasks();
  }

  getArchivedTasks() {
    this.authService.getAllUserTasks(true).subscribe(
      (response: any[]) => {
        console.log('All Archived Tasks:', response);
        // Filter out only completed and archived tasks
        this.archivedTaskList = response.filter(task => task.taskStatus === 'Completed' || task.archivedTasks);
      },
      (error: any) => {
        console.error('Error retrieving archived tasks:', error);
      }
    );
  }
  


  /*recoverTask(taskId: string) {
    this.authService.recoverTask(taskId).subscribe(
      (response: any) => {
        console.log('Task recovered successfully:', response);
        // Navigate back to the task page
        this.router.navigate(['/task']);
      },
      (error: any) => {
        console.error('Error recovering task:', error);
      }
    );
  }*/


unarchiveTask(taskId: string) {
    this.authService.unarchiveTask(taskId).subscribe(
      (response: any) => {
        console.log('Task unarchived successfully:', response);
        // Update the UI or refresh the task list as needed
        this.getArchivedTasks(); // Refresh the list after unarchiving a task
      },
      (error: any) => {
        console.error('Error unarchiving task:', error);
      }
    );
  }
}